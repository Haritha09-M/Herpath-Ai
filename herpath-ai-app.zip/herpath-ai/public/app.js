const L=[['ta','தமிழ்','ta-IN'],['hi','हिन्दी','hi-IN'],['te','తెలుగు','te-IN'],['ml','മലയാളം','ml-IN'],['kn','ಕನ್ನಡ','kn-IN'],['bn','বাংলা','bn-IN'],['mr','मराठी','mr-IN'],['gu','ગુજરાતી','gu-IN'],['pa','ਪੰਜਾਬੀ','pa-IN'],['or','ଓଡ଼ିଆ','or-IN'],['en','English','en-IN']];
const app=document.getElementById('app'),uiCache={};let ui={},ulang='en',S={},card=null,slow=false,tok=0;
const t=k=>ui[k]||k,bcp=()=>(L.find(x=>x[0]===ulang)||[0,0,'en-IN'])[2];
const h=(tag,a={},...kids)=>{const e=document.createElement(tag);for(const[k,v]of Object.entries(a))k==='class'?e.className=v:k.startsWith('on')?e.addEventListener(k.slice(2),v):e.setAttribute(k,v);for(const c of kids.flat())if(c!=null&&c!==false)e.append(c);return e};
const view=(...k)=>{app.replaceChildren(...k.flat().filter(x=>x!=null&&x!==false));scrollTo(0,0)};
const toast=m=>{const e=h('div',{class:'toast'},m);document.body.append(e);setTimeout(()=>e.remove(),3500)};
const mic=(c='mic',fn)=>{const b=h('button',{class:c,'aria-label':t('speak')});b.innerHTML='<svg viewBox="0 0 24 24"><path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.9V21h2v-3.1A7 7 0 0 0 19 11z"/></svg>';if(fn)b.onclick=fn;return b};
async function loadUi(l){if(!uiCache[l])try{uiCache[l]=await(await fetch('/api/ui/'+l)).json()}catch{uiCache[l]=uiCache.en||{}}ui=uiCache[l];ulang=l;document.documentElement.lang=l}

function stopSpeak(){tok++;speechSynthesis.cancel();document.body.classList.remove('talk')}
function speak(txt,cb){stopSpeak();if(!txt)return cb&&cb();const my=tok,u=new SpeechSynthesisUtterance(txt);u.lang=bcp();u.rate=slow?.7:.9;
 const v=speechSynthesis.getVoices().find(v=>v.lang.replace('_','-').startsWith(bcp().slice(0,2)));if(v)u.voice=v;else if(!speak.w){speak.w=1;toast(t('no_voice'))}
 u.onend=u.onerror=()=>{if(my!==tok)return;document.body.classList.remove('talk');cb&&cb()};document.body.classList.add('talk');speechSynthesis.speak(u)}
const queue=(a,i=0)=>i<a.length&&speak(a[i],()=>queue(a,i+1));

function home(){stopSpeak();view(h('section',{class:'hero'},h('h1',{},t('tagline')),h('p',{},t('tell'))),
 h('div',{class:'chips'},L.map(([c,n])=>h('button',{class:'chip'+(S.lang===c?' on':''),lang:c,onclick:()=>pick(c)},n))),
 mic('mic',record),h('p',{class:'mlabel'},t('speak')),h('button',{class:'link',onclick:typeScreen},'⌨ '+t('type_instead')),h('p',{class:'fine'},t('indep')))}
async function pick(c){S={lang:c};await loadUi(c);home();speak(t('tell'))}

function typeScreen(){view(h('div',{class:'panel'},h('textarea',{id:'tx',maxlength:500,rows:4,placeholder:t('type_here'),'aria-label':t('type_here')}),
 h('button',{class:'btn pri big',onclick:()=>{const v=document.getElementById('tx').value.trim();if(v)send({type:'text',text:v})}},t('send')),h('button',{class:'link',onclick:home},'↩ '+t('back'))))}

async function record(){stopSpeak();if(!window.MediaRecorder||!navigator.mediaDevices)return typeScreen();let st;
 try{st=await navigator.mediaDevices.getUserMedia({audio:true})}catch{toast(t('mic_denied'));return typeScreen()}
 const mt=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(m=>MediaRecorder.isTypeSupported(m)),mr=new MediaRecorder(st,mt?{mimeType:mt,audioBitsPerSecond:24000}:{}),ch=[];
 const tm=setTimeout(()=>mr.state==='recording'&&mr.stop(),15000);mr.ondataavailable=e=>ch.push(e.data);
 mr.onstop=()=>{clearTimeout(tm);st.getTracks().forEach(x=>x.stop());navigator.vibrate?.(60);const b=new Blob(ch,{type:mr.mimeType}),f=new FileReader();
  f.onload=()=>send({type:'audio',mime:(mr.mimeType||'audio/webm').split(';')[0],data:f.result.split(',')[1]});f.readAsDataURL(b)};
 mr.start();navigator.vibrate?.(40);view(h('div',{class:'listen'},mic('mic live'),h('h2',{},t('listening')),h('button',{class:'btn pri big',onclick:()=>mr.stop()},'■ '+t('tap_stop'))))}

async function send(input){view(h('div',{class:'think'},h('div',{class:'spin'}),h('p',{},t('thinking'))));
 try{const j=await(await fetch('/api/turn',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({input,state:S})})).json();
  if(j.state){S=j.state;if(S.lang&&S.lang!==ulang)await loadUi(S.lang)}route(j.view||{type:'error'})}catch{route({type:'error'})}}

const simple=(msg,extra)=>{view(h('div',{class:'panel'},h('h2',{},msg),extra));speak(msg)};
const restart=()=>h('button',{class:'btn pri big',onclick:()=>{S={lang:S.lang};home()}},t('restart'));
function route(v){switch(v.type){
 case'confirm':view(h('div',{class:'panel'},h('p',{class:'k'},t('heard')),h('p',{class:'quote'},v.transcript),h('p',{},t('correct')),
  h('div',{class:'two'},h('button',{class:'btn ok',onclick:()=>send({type:'choice',value:'yes'})},'✔ '+t('yes')),h('button',{class:'btn no',onclick:()=>send({type:'choice',value:'no'})},'✖ '+t('no')))));speak(v.transcript+'. '+t('correct'));break;
 case'question':{const q=t('q_'+v.id);view(h('div',{class:'panel'},h('h2',{},q),h('div',{class:'two'},v.options.map(([val,ic,lk])=>h('button',{class:'opt',onclick:()=>send({type:'choice',value:val})},h('span',{class:'ic'},ic),t(lk)))),h('button',{class:'link',onclick:record},'🎙 '+t('or_speak'))));speak(q);break}
 case'match':card=v.card;showCard();break;
 case'retry':simple(t('retry'),mic('mic',record));break;
 case'unsupported':simple(t('unsupported'),restart());break;
 case'sensitive':simple(t('sensitive'),restart());break;
 case'safety':simple(t('safety'),v.safety.map(s=>h('a',{class:'btn danger',href:'tel:'+s.number},'📞 '+t('call_'+s.id)+' '+s.number)));break;
 default:simple(t('error'),restart())}}

function showCard(){const c=card.text,m=card.meta,all=()=>[c.name,c.why,c.benefit,c.documents.length?t('documents')+': '+c.documents.join(', '):'',c.scam].filter(Boolean);
 const sec=(ic,title,body)=>{const arr=Array.isArray(body);return h('section',{class:'sec'},h('div',{class:'sh'},h('span',{},ic),h('h3',{},title),h('button',{class:'ear','aria-label':t('hear'),onclick:()=>speak(title+'. '+(arr?body.join('. '):body))},'🔊')),arr?h('ul',{},body.map(x=>h('li',{},x))):h('p',{},body))};
 view(h('div',{class:'card'},h('span',{class:'badge'},'🎯 '+t('match')),h('h2',{},c.name),h('span',{class:'tag'},m.abbr),m.idea?h('p',{class:'said'},t('you_said')+' “'+m.idea+'”'):null,
  sec('💡',t('why_help'),c.why),c.eligibility.length?sec('✅',t('eligible_if'),c.eligibility):null,c.benefit?sec('💰',t('benefit'),c.benefit):null,
  c.documents.length?sec('📄',t('documents'),c.documents):null,c.help.length?sec('📍',t('help_inperson'),c.help):null,h('div',{class:'warn'},'⚠ '+c.scam),h('p',{class:'fine'},t('may_be_eligible'))),
  h('nav',{class:'bar'},h('button',{class:'btn pri',onclick:()=>queue(all())},'🔊 '+t('hear_all')),c.steps.length?h('button',{class:'btn',onclick:()=>steps(0)},'👣 '+t('next_steps')):null,
   h('a',{class:'btn',href:m.url,target:'_blank',rel:'noopener noreferrer',onclick:()=>toast(t('official_note'))},'🌐 '+t('official')),
   h('button',{class:'btn ghost',onclick:()=>explain(all().join('. '))},'❓ '+t('dont_understand')),h('button',{class:'btn ghost',onclick:()=>{S={lang:S.lang};home()}},'↩ '+t('not_meant'))));
 speak(c.why)}

function steps(i){const c=card.text,n=c.steps.length;view(h('div',{class:'panel'},h('div',{class:'dots'},c.steps.map((_,j)=>h('i',{class:j<=i?'on':''}))),h('p',{class:'k'},t('step')+' '+(i+1)+'/'+n),h('p',{class:'big'},c.steps[i]),
 h('div',{class:'two'},h('button',{class:'btn',onclick:()=>speak(c.steps[i])},'🔁 '+t('replay')),h('button',{class:'btn',onclick:()=>{slow=!slow;speak(c.steps[i])}},'🐢 '+t('slower'))),
 h('div',{class:'two'},h('button',{class:'btn',onclick:()=>i?steps(i-1):showCard()},'◀ '+t('back')),i<n-1?h('button',{class:'btn pri',onclick:()=>steps(i+1)},t('next')+' ▶'):h('button',{class:'btn pri',onclick:showCard},'✔ '+t('done'))),
 h('button',{class:'link',onclick:()=>explain(c.steps[i])},'❓ '+t('dont_understand'))));speak(c.steps[i])}

async function explain(txt){document.querySelector('.sheet')?.remove();const sh=h('div',{class:'sheet'},h('div',{class:'spin'}));document.body.append(sh);
 try{const j=await(await fetch('/api/explain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lang:S.lang||ulang,text:txt.slice(0,800)})})).json();
  sh.replaceChildren(h('p',{},j.text),h('div',{class:'two'},h('button',{class:'btn',onclick:()=>speak(j.text)},'🔊 '+t('hear')),h('button',{class:'btn pri',onclick:()=>{sh.remove();stopSpeak()}},t('ok'))));speak(j.text)}catch{sh.remove();toast(t('error'))}}

loadUi('en').then(home);
