import { readFileSync } from 'node:fs';
export const DB = JSON.parse(readFileSync(new URL('../data/schemes.json', import.meta.url)));
export const LANGS = { ta:['தமிழ்','Tamil'], hi:['हिन्दी','Hindi'], te:['తెలుగు','Telugu'], ml:['മലയാളം','Malayalam'], kn:['ಕನ್ನಡ','Kannada'], bn:['বাংলা','Bengali'], mr:['मराठी','Marathi'], gu:['ગુજરાતી','Gujarati'], pa:['ਪੰਜਾਬੀ','Punjabi'], or:['ଓଡ଼ିଆ','Odia'], en:['English','English'] };
export const UI_EN = {tagline:'Your Voice. Your Need. Your Next Step.',tell:'Tell us what help you need. You do not need to know the scheme name.',speak:'Tap and speak',type_instead:'Type instead',listening:'Listening… speak now',tap_stop:'Tap when finished',thinking:'Please wait…',heard:'We heard:',correct:'Is this correct?',yes:'Yes',no:'No',retry:'Sorry, we could not understand. Please tap the button and say it again.',q_status:'Is your business NEW, or is it already running?',new:'New business',existing:'Already running',q_area:'Where will the business be?',village:'In a village',town:'In a town or city',or_speak:'Answer by speaking',match:'Possible match for you',you_said:'You said:',why_help:'How this may help you',eligible_if:'You may be eligible if',benefit:'What you may get',documents:'Papers you need',next_steps:'Show steps',step:'Step',back:'Back',next:'Next',replay:'Hear again',slower:'Slower',done:'Done',help_inperson:'Get help in person',official:'Official website',official_note:'This opens the government website on your phone.',hear:'Listen',hear_all:'Listen to all',dont_understand:'I do not understand',not_meant:'That is not what I meant',may_be_eligible:'Based on what you told us, you may be eligible. Please check the current rules on the official website.',unsupported:'Right now we can only help with starting a small business. More help is coming soon.',sensitive:'Please do not tell anyone your OTP, PIN, password or Aadhaar number. We do not need it.',safety:'You are not alone. If you are in danger, please call for help now.',call_women:'Women Helpline',call_emergency:'Emergency',error:'Something went wrong. Please try again.',mic_denied:'Microphone is not available. You can type instead.',type_here:'Type here what help you need',send:'Send',no_voice:'Voice for this language is not on this phone. Please read the screen.',ok:'OK',restart:'Start again',indep:'Independent prototype. Not a government website.'};

const ascii = /^[0-9.]+$/;
export const nums = s => String(s).match(/\p{Nd}+(?:\.\p{Nd}+)?/gu) || [];
export const guardOk = (src, out) => {
  const o = JSON.stringify(out), a = new Set(nums(JSON.stringify(src)));
  if (/https?:\/\//i.test(o) && !/https?:\/\//i.test(JSON.stringify(src))) return false;
  return nums(o).every(n => a.has(n) || (ascii.test(n) && n.length === 1));
};
export const shape = o => Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.entries(o).map(([k, v]) => [k, shape(v)])) : 1;
export const sameShape = (a, b) => JSON.stringify(shape(a)) === JSON.stringify(shape(b));

function buildCard(s, st) {
  const meta = { abbr: s.abbr, url: s.url, idea: st.idea || '' }, b = s.benefit;
  if (st.status === 'existing')
    return { meta: { ...meta, notEligible: true }, text: { name: s.name, why: 'This scheme is only for NEW businesses. Your business is already running, so it may not fit. You can ask at the places below about other options.', eligibility: [], benefit: '', documents: [], steps: [], help: s.help, scam: s.scam } };
  const rural = st.area === 'rural';
  return { meta, text: { name: s.name, why: s.purpose, eligibility: s.eligibility,
    benefit: `Women get a ${rural ? b.rural : b.urban}% subsidy on the project cost in a ${rural ? 'village' : 'town or city'}. You put in about ${b.own}% yourself. The bank gives a loan for the rest. The project can cost up to Rs ${b.max_manufacturing_lakh} lakh for making things, or Rs ${b.max_service_lakh} lakh for services.`,
    documents: s.documents, steps: s.steps, help: s.help, scam: s.scam } };
}

// Deterministic matcher: the LLM never decides which scheme or which facts are shown.
export function nextView(st) {
  const s = DB.schemes.find(x => x.category === st.cat);
  if (!s) return { type: 'unsupported' };
  if (!st.status || st.status === 'unknown') return { type: 'question', id: 'status', options: [['new', '🌱', 'new'], ['existing', '🏪', 'existing']] };
  if (st.status === 'existing') return { type: 'match', card: buildCard(s, st) };
  if (!st.area || st.area === 'unknown') return { type: 'question', id: 'area', options: [['rural', '🌾', 'village'], ['urban', '🏙️', 'town']] };
  return { type: 'match', card: buildCard(s, st) };
}
