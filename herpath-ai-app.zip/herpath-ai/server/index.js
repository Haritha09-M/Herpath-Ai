import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import pino from 'pino';
import { z } from 'zod';
import { intent, translateJSON, simplify } from './gemini.js';
import { DB, LANGS, UI_EN, nextView, guardOk, sameShape, nums } from './logic.js';

const log = pino({ level: process.env.LOG_LEVEL || 'info' }); // never log user text
const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], mediaSrc: ["'self'", 'blob:'], objectSrc: ["'none'"], frameAncestors: ["'none'"], upgradeInsecureRequests: null } } }));
app.use(express.json({ limit: '3mb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 40, standardHeaders: true, legacyHeaders: false, message: { view: { type: 'error' } } }));

const cache = new Map();
const cached = async (key, fn) => cache.get(key) ?? (cache.set(key, await fn()), cache.get(key));

app.get('/api/health', (_, res) => res.json({ ok: true, ai: !!process.env.GEMINI_API_KEY }));

app.get('/api/ui/:lang', async (req, res) => {
  const lang = req.params.lang;
  if (!LANGS[lang] || lang === 'en') return res.json(UI_EN);
  try {
    res.json(await cached('ui' + lang, async () => {
      const o = await translateJSON(UI_EN, lang);
      if (!sameShape(UI_EN, o) || !guardOk(UI_EN, o)) throw new Error('guard');
      return o;
    }));
  } catch (e) { log.warn({ e: e.message }, 'ui fallback'); res.json(UI_EN); }
});

async function localise(card, lang) {
  if (!lang || lang === 'en' || !LANGS[lang]) return card;
  try {
    const text = await cached('card' + lang + JSON.stringify(card.text), async () => {
      const o = await translateJSON(card.text, lang);
      if (!sameShape(card.text, o) || !guardOk(card.text, o)) throw new Error('guard');
      return o;
    });
    return { ...card, text };
  } catch (e) { log.warn({ e: e.message }, 'card shown in English (guard/translate failed)'); return card; }
}

const St = z.object({ lang: z.string().max(3).nullable().optional(), cat: z.string().nullable().optional(), status: z.string().nullable().optional(), area: z.string().nullable().optional(), idea: z.string().max(120).nullable().optional(), expect: z.string().nullable().optional() }).strict();
const Turn = z.object({ state: St.default({}), input: z.discriminatedUnion('type', [
  z.object({ type: z.literal('audio'), mime: z.enum(['audio/webm', 'audio/mp4', 'audio/ogg']), data: z.string().max(2_000_000) }),
  z.object({ type: z.literal('text'), text: z.string().min(1).max(500) }),
  z.object({ type: z.literal('choice'), value: z.enum(['yes', 'no', 'new', 'existing', 'rural', 'urban']) })]) });

app.post('/api/turn', async (req, res) => {
  const p = Turn.safeParse(req.body);
  if (!p.success) return res.status(400).json({ view: { type: 'error' } });
  const { input } = p.data; let st = { ...p.data.state };
  const out = (view) => res.json({ state: st, view });
  try {
    if (input.type === 'choice') {
      const v = input.value;
      if (v === 'no') { st = { lang: st.lang }; return out({ type: 'retry' }); }
      if (v === 'new' || v === 'existing') st.status = v; else if (v === 'rural' || v === 'urban') st.area = v;
    } else {
      const r = await intent(input, st.expect, st.lang);
      if (r.category === 'safety_concern') return out({ type: 'safety', safety: DB.safety });
      if (r.category === 'sensitive_data_shared') return out({ type: 'sensitive' });
      if (r.confidence < 0.45) return out({ type: 'retry' });
      if (LANGS[r.language] && r.confidence >= 0.5) st.lang = r.language;
      if (!st.cat) { // first utterance
        if (r.category === 'other_service_request') return out({ type: 'unsupported' });
        if (r.category !== 'self_employment') return out({ type: 'retry' });
        st.cat = 'self_employment'; st.idea = (r.business_idea || '').slice(0, 80);
        if (r.business_status !== 'unknown') st.status = r.business_status;
        if (r.area !== 'unknown') st.area = r.area;
        return out({ type: 'confirm', transcript: r.transcript }); // echo-confirm what we heard
      }
      if (st.expect === 'status' && r.business_status !== 'unknown') st.status = r.business_status;
      else if (st.expect === 'area' && r.area !== 'unknown') st.area = r.area;
      else return out({ type: 'retry' });
    }
    const v = nextView(st);
    st.expect = v.type === 'question' ? v.id : null;
    if (v.type === 'match') v.card = await localise(v.card, st.lang);
    out(v);
  } catch (e) { log.error({ e: e.message }, 'turn failed'); res.json({ state: st, view: { type: 'error' } }); }
});

app.post('/api/explain', async (req, res) => {
  const p = z.object({ lang: z.string().max(3), text: z.string().min(1).max(800) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ text: '' });
  try {
    const t = await simplify(p.data.text, p.data.lang), src = nums(p.data.text);
    res.json({ text: nums(t).every(n => src.includes(n)) && !/https?:\/\//i.test(t) ? t : p.data.text });
  } catch (e) { log.error({ e: e.message }, 'explain failed'); res.json({ text: p.data.text }); }
});

app.use(express.static(new URL('../public', import.meta.url).pathname));
app.listen(process.env.PORT || 8080, '0.0.0.0', () => log.info('HERPATH AI running'));
