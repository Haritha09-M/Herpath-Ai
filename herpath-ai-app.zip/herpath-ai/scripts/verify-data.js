import { DB } from '../server/logic.js';
let bad = 0;
for (const s of DB.schemes) {
  for (const k of ['name', 'purpose', 'eligibility', 'benefit', 'documents', 'steps', 'help', 'scam', 'url', 'last_verified']) if (!s[k]) { console.error('missing', s.id, k); bad++; }
  if (String(s.verified_by).startsWith('PENDING')) console.warn(`WARNING ${s.id}: re-check every field at ${s.url}, then update verified_by`);
}
process.exit(bad ? 1 : 0);
