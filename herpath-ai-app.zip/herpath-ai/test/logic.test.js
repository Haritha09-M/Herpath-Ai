import test from 'node:test';
import assert from 'node:assert/strict';
import { nextView, guardOk } from '../server/logic.js';
test('asks status, then area, then matches', () => {
  assert.equal(nextView({ cat: 'self_employment' }).id, 'status');
  assert.equal(nextView({ cat: 'self_employment', status: 'new' }).id, 'area');
  assert.equal(nextView({ cat: 'self_employment', status: 'new', area: 'rural' }).type, 'match');
  assert.equal(nextView({ cat: 'self_employment', status: 'existing' }).card.meta.notEligible, true);
});
test('other categories are unsupported', () => assert.equal(nextView({ cat: 'x' }).type, 'unsupported'));
test('guard blocks invented numbers', () => {
  assert.equal(guardOk({ a: '35% and 5%' }, { a: '35% 5%' }), true);
  assert.equal(guardOk({ a: '35%' }, { a: '45%' }), false);
});
